

using DelimitedFiles
using DataFrames, CSV
PATH = "./instances_COR/25Vertices/"
filename = "25vertices_bitcoinotc_S1.txt"

println("[INFO] Loading Distances matrix_epinions epinions")
NUM_NODES = 25
NUM_EDGES = 25
# matrix_epinions = zeros(Int8,NUM_NODES,NUM_NODES)
init_row = 1
init_column = 1
final_row = 25
final_column = 25

reader = readdlm(PATH*filename)
# println(reader[2:26,:])
matrix = reader[2:26,:]

matrix_bitcoinotc = zeros(Int, 25, 25)
for i in 1:25
    for j in 1:25
        if (matrix[i,j] != 0)
            coin = rand(0:3)
            if coin > 0
                matrix_bitcoinotc[i,j] = matrix[i,j]
            end
        end
    end
end

num_pos = 0
num_neg = 0
for i in 1:25
    for j in 1:25
        if matrix_bitcoinotc[i,j] > 0  global num_pos+=1 end 
        if matrix_bitcoinotc[i,j] < 0  global num_neg+=1 end 
    end
end

println("Num of positive arcs: ",num_pos)
println("Num of negative arcs: ",num_neg)




# matrix_epinions = zeros(Int, (final_row - init_row + 1), (final_column - init_column + 1)) 
# if isfile(PATH*filename)
#     reader = readdlm(PATH*filename)
#     nrows = NUM_EDGES
#     for i in 5:nrows  #first line == collumns names
#         line = reader[i,:] 
#         if line[1]+1 >= init_row && line[1]+1<=final_row && line[2]+1 >= init_column && line[2]+1 <=final_column
#             matrix_epinions[line[1]+1,line[2]+1] = line[3]
#         end
#     end
# else
#     println("No distance matrix_epinions file exists")
#     return 0
# end