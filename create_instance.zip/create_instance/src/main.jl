
using DelimitedFiles
using DataFrames, CSV


PATH = "./instances/"
filename = "soc-sign-epinions.txt"

# println("[INFO] Loading Instance: ", filename)
# if isfile(PATH*filename)
#     reader = readdlm(PATH*filename)
#     header, data = reader[4,:], reader[5:30,1:3]
#     df = DataFrames.DataFrame(data, header[2:end-1])
#     df[!,:FromNodeId] = convert.(Int,df[!,:FromNodeId])
#     df[!,:ToNodeId] = convert.(Int,df[!,:ToNodeId])
#     df[!,:Sign] = convert.(Int,df[!,:Sign])
# else
#     println("No epinions file exists")
#     return 0
# end

# println(df)
# println(df[5,:"FromNodeId"])


# println("[INFO] Loading Distances matrix_epinions epinions")
# NUM_NODES = 131828
# NUM_EDGES = 841372
# # matrix_epinions = zeros(Int8,NUM_NODES,NUM_NODES)
# init_row = 1
# init_column = 1
# final_row = 25
# final_column = 25

# matrix_epinions = zeros(Int, (final_row - init_row + 1), (final_column - init_column + 1)) 
# if isfile(PATH*filename)
#     reader = readdlm(PATH*filename)
#     nrows = NUM_EDGES
#     for i in 5:nrows  #first line == collumns names
#         line = reader[i,:] 
#         if line[1]+1 >= init_row && line[1]+1<=final_row && line[2]+1 >= init_column && line[2]+1 <=final_column
#             matrix_epinions[line[1]+1,line[2]+1] = line[3]
#         end
#     end
# else
#     println("No distance matrix_epinions file exists")
#     return 0
# end

# println(matrix_epinions[1,25])
# println(matrix_epinions[5,25])
# println(matrix_epinions[6,9])

# num_pos = 0
# num_neg = 0
# for i in 1:(final_row - init_row + 1)
#     for j in 1:(final_column - init_column + 1)
#         if matrix_epinions[i,j] > 0 global num_pos+=1 end 
#         if matrix_epinions[i,j] < 0 global num_neg+=1 end 
#     end
# end

# println("Num of positive arcs: ",num_pos)
# println("Num of negative arcs: ",num_neg)


# -------------------------------------- bitcoinotc ---------------------------------------
# exit()
filename = "soc-sign-bitcoinotc.csv"


global max_dens = 0
global max_init = 0
for INIT in 1:5831
    # println("[INFO] Loading Distances matrix_bitcoinotc")
    NUM_NODES = 5881
    NUM_EDGES = 35592
    # matrix_epinions = zeros(Int8,NUM_NODES,NUM_NODES)
    init_row = INIT
    init_column = INIT
    final_row = INIT+49
    final_column = INIT+49

    matrix_bitcoinotc = zeros(Int, (final_row - init_row + 1), (final_column - init_column + 1)) 
    if isfile(PATH*filename)
        reader = readdlm(PATH*filename,',',Int) # remove last column 
        nrows = NUM_EDGES
        for i in 5:nrows  #first line == collumns names
            line = reader[i,:] 
            if line[1]+1 >= init_row && line[1]+1<=final_row && line[2]+1 >= init_column && line[2]+1 <=final_column
                
                if line[3] > 0
                    matrix_bitcoinotc[(line[1]+2-INIT),(line[2]+2-INIT)] = 1
                end
                if line[3] < 0
                    matrix_bitcoinotc[(line[1]+2-INIT),(line[2]+2-INIT)] = -1
                end
            end
        end
    else
        println("No distance matrix_bitcoinotc file exists")
        return 0
    end


    num_pos = 0
    num_neg = 0
    for i in 1:(final_row - init_row + 1)
        for j in 1:(final_column - init_column + 1)
            if matrix_bitcoinotc[i,j] > 0  num_pos+=1 end 
            if matrix_bitcoinotc[i,j] < 0  num_neg+=1 end 
        end
    end

    if num_pos + num_neg > max_dens
        global max_dens = num_pos + num_neg
        global max_init = INIT
        println(max_dens)
        println("init: ", INIT)
    end



end


println("\n\n\n Epinions \n\n\n")

filename = "soc-sign-epinions.txt"


global max_dens = 0
global max_init = 0
for INIT in 1:(131828-50)
    # println("[INFO] Loading Distances matrix_bitcoinotc")
    NUM_NODES = 131828
    NUM_EDGES = 841372
    # matrix_epinions = zeros(Int8,NUM_NODES,NUM_NODES)
    init_row = INIT
    init_column = INIT
    final_row = INIT+49
    final_column = INIT+49

    matrix_epinions = zeros(Int, (final_row - init_row + 1), (final_column - init_column + 1)) 
    if isfile(PATH*filename)
        reader = readdlm(PATH*filename) # remove last column 
        nrows = NUM_EDGES
        for i in 5:nrows  #first line == collumns names
            line = reader[i,:] 
            if line[1]+1 >= init_row && line[1]+1<=final_row && line[2]+1 >= init_column && line[2]+1 <=final_column
                
                if line[3] > 0
                    matrix_epinions[(line[1]+2-INIT),(line[2]+2-INIT)] = 1
                end
                if line[3] < 0
                    matrix_epinions[(line[1]+2-INIT),(line[2]+2-INIT)] = -1
                end
            end
        end
    else
        println("No distance matrix_epinions file exists")
        return 0
    end


    num_pos = 0
    num_neg = 0
    for i in 1:(final_row - init_row + 1)
        for j in 1:(final_column - init_column + 1)
            if matrix_epinions[i,j] > 0  num_pos+=1 end 
            if matrix_epinions[i,j] < 0  num_neg+=1 end 
        end
    end

    if num_pos + num_neg > max_dens
        global max_dens = num_pos + num_neg
        global max_init = INIT
        println(max_dens)
        println("init: ", INIT)
    end



end





