
using DelimitedFiles
using DataFrames, CSV


PATH = "./instances/"
filename = "soc-sign-bitcoinotc.csv"



println("[INFO] Loading Distances matrix_bitcoinotc")

# 50v
# vet_vertices_S1 = [4291, 2388, 2063, 1899, 1, 353, 546, 1810, 57, 1731, 2125, 3598, 1832, 4649, 2625, 3897, 13, 2296, 905, 1953, 3451, 2028, 3744, 1334, 729, 4611, 35, 2642, 3735, 1018, 3828, 4197, 4172, 2642, 1731, 353, 2063, 905, 4172, 304, 546, 1334, 2388, 2942, 1832, 2642, 3714, 1396, 3429, 3451]
# vet_vertices_S2 = [2897, 2045, 35, 3828, 304, 4172, 1386, 1, 2942, 135, 1810, 1566, 3878, 1832, 3897, 1555, 2625, 729, 1352, 3465, 2642, 57, 353, 2176, 361, 905, 4559, 2028, 1366, 2067, 1585, 2296, 1731, 3903, 1565, 3828, 135, 2642, 905, 1334, 1832, 1832, 3598, 215, 1802, 215, 4291, 1802, 3451, 3452]
# vet_vertices_S3 = [4694, 4635, 1363, 4683, 1953, 3897, 905, 4684, 3757, 2028, 3756, 2388, 4680, 135, 4707, 4675, 4172, 4681, 1383, 4688, 4682, 1810, 2063, 1967, 1363, 4499, 3793, 1, 1396, 4197, 2388, 4688, 1815, 1953, 3793, 1565, 3903, 1352, 4682, 2028, 135, 550, 353, 4683, 4686, 3897, 4291, 4197, 4458, 905]

#100v
# vet_vertices_S1 = [4833, 1316, 304, 1396, 64, 1714, 7, 550, 4559, 2388, 1386, 2934, 1201, 3714, 664, 1675, 1802, 309, 4694, 546, 1953, 3719, 2110, 2397, 1366, 2063, 3744, 1317, 2625, 2296, 2125, 1053, 2942, 1693, 1565, 1810, 1383, 2045, 1543, 353, 1731, 1334, 2642, 4365, 202, 4291, 1502, 3988, 1566, 1585, 4197, 2404, 3820, 905, 1352, 2176, 135, 2028, 592, 3465, 3828, 4611, 363, 2067, 4172, 1629, 215, 1018, 2176, 905, 1543, 1317, 1832, 1366, 546, 1565, 2045, 1386, 2110, 4291, 1693, 1334, 1731, 1396, 2388, 2125, 353, 2125, 4197, 1, 1714, 2125, 1316, 3988, 3820, 363, 3429, 1502, 1334, 905]
# vet_vertices_S2 = [1860, 353, 882, 2067, 2934, 2942, 4515, 35, 1366, 2600, 2728, 13, 4217, 2296, 4402, 202, 1620, 1281, 1363, 3545, 3897, 1802, 1, 4833, 3744, 280, 2124, 135, 4532, 178, 3820, 905, 2045, 1916, 1529, 1953, 729, 2252, 363, 1899, 204, 104, 1396, 4360, 1566, 1245, 361, 1693, 1860, 1334, 1222, 3820, 546, 1771, 280, 3916, 2600, 2388, 2942, 113, 1529, 1693, 1832, 3451, 2710, 3897, 2296, 905, 1352, 1735, 3815, 2625, 882, 1899, 1802, 3714, 1366, 1713, 4197, 546, 2306, 2173, 2110, 546, 1953, 1396, 635, 729, 1555, 1352, 4172, 1396, 3040, 2561, 1612, 1967, 425, 2214, 2173, 2176]
# vet_vertices_S3 = [3760, 4686, 2962, 1656, 2214, 309, 4635, 4038, 1719, 2194, 2266, 3757, 4682, 4707, 4668, 1334, 4679, 5472, 905, 4666, 4683, 1953, 4672, 4667, 1363, 3759, 3792, 2173, 2028, 4694, 1318, 1565, 1771, 3787, 3744, 3791, 4743, 3795, 1383, 1810, 4733, 215, 4678, 2962, 1185, 2045, 2198, 2962, 3791, 1810, 4291, 4688, 2795, 1953, 1565, 1899, 2897, 905, 1967, 4672, 2174, 1620, 1757, 2728, 2728, 2266, 1714, 2642, 1383, 2028, 2392, 1802, 2388, 4688, 2725, 3013, 1018, 1810, 2178, 1719, 4707, 2795, 4733, 905, 1, 4682, 4119, 1363, 2642, 309, 1629, 3531, 1810, 1953, 3788, 2763, 1281, 2388, 353, 4616]

vet_vertices = vet_vertices_S3
num_vertices = 100

# println(length(vet_vertices))
# exit()


NUM_NODES = 5881
NUM_EDGES = 35592

matrix_bitcoinotc = zeros(Int, num_vertices, num_vertices) 
if isfile(PATH*filename)
    reader = readdlm(PATH*filename,',',Int) # remove last column 
    nrows = NUM_EDGES
    for i in 1:nrows  #first line == collumns names
        line = reader[i,:] 
        if line[1] in vet_vertices && line[2] in vet_vertices 
            
            v1 = findfirst(item -> item == line[1], vet_vertices)
            v2 = findfirst(item -> item == line[2], vet_vertices)
            matrix_bitcoinotc[v1,v2] = line[3] 
        end
    end
else
    println("No distance matrix_bitcoinotc file exists")
    return 0
end


num_pos = 0
num_neg = 0
for i in 1:num_vertices
    for j in 1:num_vertices
        if matrix_bitcoinotc[i,j] > 0  global num_pos+=1 end 
        if matrix_bitcoinotc[i,j] < 0  global num_neg+=1 end 
    end
end

println("Num of positive arcs: ",num_pos)
println("Num of negative arcs: ",num_neg)

file_output = "100vertices_bitcoinotc_directed_S3.txt"

open("./output_instances/"*file_output,"a") do file
    write(file,"$(num_vertices)")
    write(file,"\n")
    for i in 1:num_vertices
        for j in 1:num_vertices
            write(file,"$(matrix_bitcoinotc[i,j])")
            write(file," ")
        end

        write(file,"\n")    # write(file,"\n")
    end
    write(file,"\n")
    write(file,"BitCoin Vertices:")
    write(file,"\n")
    write(file,"3760, 4686, 2962, 1656, 2214, 309, 4635, 4038, 1719, 2194, 2266, 3757, 4682, 4707, 4668, 1334, 4679, 5472, 905, 4666, 4683, 1953, 4672, 4667, 1363, 3759, 3792, 2173, 2028, 4694, 1318, 1565, 1771, 3787, 3744, 3791, 4743, 3795, 1383, 1810, 4733, 215, 4678, 2962, 1185, 2045, 2198, 2962, 3791, 1810, 4291, 4688, 2795, 1953, 1565, 1899, 2897, 905, 1967, 4672, 2174, 1620, 1757, 2728, 2728, 2266, 1714, 2642, 1383, 2028, 2392, 1802, 2388, 4688, 2725, 3013, 1018, 1810, 2178, 1719, 4707, 2795, 4733, 905, 1, 4682, 4119, 1363, 2642, 309, 1629, 3531, 1810, 1953, 3788, 2763, 1281, 2388, 353, 4616")
    write(file,"\n")
    write(file,"NUM EDGES NEG = $(num_neg)")
    write(file,"\n")
    write(file,"NUM EDGES POS = $(num_pos)")

end


# println("[INFO] Loading Instance: ", filename)
# if isfile(PATH*filename)
#     reader = readdlm(PATH*filename)
#     header, data = reader[4,:], reader[5:30,1:3]
#     df = DataFrames.DataFrame(data, header[2:end-1])
#     df[!,:FromNodeId] = convert.(Int,df[!,:FromNodeId])
#     df[!,:ToNodeId] = convert.(Int,df[!,:ToNodeId])
#     df[!,:Sign] = convert.(Int,df[!,:Sign])
# else
#     println("No epinions file exists")
#     return 0
# end

# println(df)
# println(df[5,:"FromNodeId"])


# println("[INFO] Loading Distances matrix_epinions epinions")
# NUM_NODES = 131828
# NUM_EDGES = 841372
# # matrix_epinions = zeros(Int8,NUM_NODES,NUM_NODES)
# init_row = 1filename = "soc-sign-bitcoinotc.csv"


# global max_dens = 0
# global max_init = 0
# for INIT in 1:5831
#     # println("[INFO] Loading Distances matrix_bitcoinotc")
#     NUM_NODES = 5881
#     NUM_EDGES = 35592
#     # matrix_epinions = zeros(Int8,NUM_NODES,NUM_NODES)
#     init_row = INIT
#     init_column = INIT
#     final_row = INIT+49
#     final_column = INIT+49

#     matrix_bitcoinotc = zeros(Int, (final_row - init_row + 1), (final_column - init_column + 1)) 
#     if isfile(PATH*filename)
#         reader = readdlm(PATH*filename,',',Int) # remove last column 
#         nrows = NUM_EDGES
#         for i in 5:nrows  #first line == collumns names
#             line = reader[i,:] 
#             if line[1]+1 >= init_row && line[1]+1<=final_row && line[2]+1 >= init_column && line[2]+1 <=final_column
                
#                 if line[3] > 0
#                     matrix_bitcoinotc[(line[1]+2-INIT),(line[2]+2-INIT)] = 1
#                 end
#                 if line[3] < 0
#                     matrix_bitcoinotc[(line[1]+2-INIT),(line[2]+2-INIT)] = -1
#                 end
#             end
#         end
#     else
#         println("No distance matrix_bitcoinotc file exists")
#         return 0
#     end


#     num_pos = 0
#     num_neg = 0
#     for i in 1:(final_row - init_row + 1)
#         for j in 1:(final_column - init_column + 1)
#             if matrix_bitcoinotc[i,j] > 0  num_pos+=1 end 
#             if matrix_bitcoinotc[i,j] < 0  num_neg+=1 end 
#         end
#     end

#     if num_pos + num_neg > max_dens
#         global max_dens = num_pos + num_neg
#         global max_init = INIT
#         println(max_dens)
#         println("init: ", INIT)
#     end



# end
# init_column = 1
# final_row = 25
# final_column = 25

# matrix_epinions = zeros(Int, (final_row - init_row + 1), (final_column - init_column + 1)) 
# if isfile(PATH*filename)
#     reader = readdlm(PATH*filename)
#     nrows = NUM_EDGES
#     for i in 5:nrows  #first line == collumns names
#         line = reader[i,:] 
#         if line[1]+1 >= init_row && line[1]+1<=final_row && line[2]+1 >= init_column && line[2]+1 <=final_column
#             matrix_epinions[line[1]+1,line[2]+1] = line[3]
#         end
#     end
# else
#     println("No distance matrix_epinions file exists")
#     return 0
# end

# println(matrix_epinions[1,25])
# println(matrix_epinions[5,25])
# println(matrix_epinions[6,9])

# num_pos = 0
# num_neg = 0
# for i in 1:(final_row - init_row + 1)
#     for j in 1:(final_column - init_column + 1)
#         if matrix_epinions[i,j] > 0 global num_pos+=1 end 
#         if matrix_epinions[i,j] < 0 global num_neg+=1 end 
#     end
# end

# println("Num of positive arcs: ",num_pos)
# println("Num of negative arcs: ",num_neg)


# -------------------------------------- bitcoinotc ---------------------------------------
# exit()
# filename = "soc-sign-bitcoinotc.csv"


# global max_dens = 0
# global max_init = 0
# for INIT in 1:5831
#     # println("[INFO] Loading Distances matrix_bitcoinotc")
#     NUM_NODES = 5881
#     NUM_EDGES = 35592
#     # matrix_epinions = zeros(Int8,NUM_NODES,NUM_NODES)
#     init_row = INIT
#     init_column = INIT
#     final_row = INIT+49
#     final_column = INIT+49

#     matrix_bitcoinotc = zeros(Int, (final_row - init_row + 1), (final_column - init_column + 1)) 
#     if isfile(PATH*filename)
#         reader = readdlm(PATH*filename,',',Int) # remove last column 
#         nrows = NUM_EDGES
#         for i in 5:nrows  #first line == collumns names
#             line = reader[i,:] 
#             if line[1]+1 >= init_row && line[1]+1<=final_row && line[2]+1 >= init_column && line[2]+1 <=final_column
                
#                 if line[3] > 0
#                     matrix_bitcoinotc[(line[1]+2-INIT),(line[2]+2-INIT)] = 1
#                 end
#                 if line[3] < 0
#                     matrix_bitcoinotc[(line[1]+2-INIT),(line[2]+2-INIT)] = -1
#                 end
#             end
#         end
#     else
#         println("No distance matrix_bitcoinotc file exists")
#         return 0
#     end


#     num_pos = 0
#     num_neg = 0
#     for i in 1:(final_row - init_row + 1)
#         for j in 1:(final_column - init_column + 1)
#             if matrix_bitcoinotc[i,j] > 0  num_pos+=1 end 
#             if matrix_bitcoinotc[i,j] < 0  num_neg+=1 end 
#         end
#     end

#     if num_pos + num_neg > max_dens
#         global max_dens = num_pos + num_neg
#         global max_init = INIT
#         println(max_dens)
#         println("init: ", INIT)
#     end



# end


# println("\n\n\n Epinions \n\n\n")

# filename = "soc-sign-epinions.txt"


# global max_dens = 0
# global max_init = 0
# for INIT in 1:(131828-50)
#     # println("[INFO] Loading Distances matrix_bitcoinotc")
#     NUM_NODES = 131828
#     NUM_EDGES = 841372
#     # matrix_epinions = zeros(Int8,NUM_NODES,NUM_NODES)
#     init_row = INIT
#     init_column = INIT
#     final_row = INIT+49
#     final_column = INIT+49

#     matrix_epinions = zeros(Int, (final_row - init_row + 1), (final_column - init_column + 1)) 
#     if isfile(PATH*filename)
#         reader = readdlm(PATH*filename) # remove last column 
#         nrows = NUM_EDGES
#         for i in 5:nrows  #first line == collumns names
#             line = reader[i,:] 
#             if line[1]+1 >= init_row && line[1]+1<=final_row && line[2]+1 >= init_column && line[2]+1 <=final_column
                
#                 if line[3] > 0
#                     matrix_epinions[(line[1]+2-INIT),(line[2]+2-INIT)] = 1
#                 end
#                 if line[3] < 0
#                     matrix_epinions[(line[1]+2-INIT),(line[2]+2-INIT)] = -1
#                 end
#             end
#         end
#     else
#         println("No distance matrix_epinions file exists")
#         return 0
#     end


#     num_pos = 0
#     num_neg = 0
#     for i in 1:(final_row - init_row + 1)
#         for j in 1:(final_column - init_column + 1)
#             if matrix_epinions[i,j] > 0  num_pos+=1 end 
#             if matrix_epinions[i,j] < 0  num_neg+=1 end 
#         end
#     end

#     if num_pos + num_neg > max_dens
#         global max_dens = num_pos + num_neg
#         global max_init = INIT
#         println(max_dens)
#         println("init: ", INIT)
#     end



# end





