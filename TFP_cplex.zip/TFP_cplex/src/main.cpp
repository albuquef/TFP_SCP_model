#include <iostream>


#include "graph.h"

#include "reader.h"
#include "TFP_SCP.h"
#include "matching.h"
using namespace std;

int main(int argc, char** argv){


    cout << "You have entered " << argc << " arguments:"
         << "\n";
 
    // for (int i = 0; i < argc; ++i)                                   
    //     cout << argv[i] << "\n";

    // Reader rd(false,14, 1,1, "random");

    // const char* SEC = "MTZ";
    // TFP_SCP prob = TFP_SCP(&rd,SEC); 
    // prob.solveILP();

    // const char* SEC_2 = "SIGN";
    // TFP_SCP prob2 = TFP_SCP(&rd,SEC_2);
    // prob2.solveILP();

    Reader rd(false,4, 2,1, "random");
    // rd.show();

    Graph graph = Graph(rd.G, rd.num_vertices, rd.G_type);
    graph.genereateGraph_weighted("MinMatching");

    cout << " Graph Matrix Weighted SPP \n";
    for (int u = 0; u < rd.num_vertices; u++){
        for (int v = 0; v < rd.num_vertices; v++)
        cout <<  graph.Graph_SPP[u][v] << " ";
        cout<< "\n";
    }



    return 0;
}
