#include <iostream>


#include "graph.h"

#include "reader.h"
#include "TFP_SCP.h"
#include "matching.h"
using namespace std;

int main(int argc, char** argv){


    cout << "You have entered " << argc << " arguments:"
         << "\n";
 
    // for (int i = 0; i < argc; ++i)                                   
    //     cout << argv[i] << "\n";

    // Reader rd(false,14, 1,1, "random");

    // const char* SEC = "MTZ";
    // TFP_SCP prob = TFP_SCP(&rd,SEC); 
    // prob.solveILP();

    // const char* SEC_2 = "SIGN";
    // TFP_SCP prob2 = TFP_SCP(&rd,SEC_2);
    // prob2.solveILP();

    Reader rd(false,4, 2,1, "random");
    rd.show();

    Graph graph = Graph(rd.G, rd.num_vertices, rd.G_type);




    return 0;
}
