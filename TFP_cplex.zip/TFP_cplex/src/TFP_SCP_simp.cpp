#include "TFP_SCP_simp.h"

double get_wall_time(){
    struct timeval time;
    if(gettimeofday(&time,nullptr)){
        // HANDLE ERROR
        return 0;
    }else{
        return static_cast<double>(time.tv_sec) + static_cast<double>(time.tv_usec*0.000001); //microsegundos
    }
}

TFP_SCP_SIMP::TFP_SCP_SIMP(Reader *r, const Graph & Grph,const char* method_SPP): rd(r), GRAPH(Grph){
// TFP_SCP_SIMP::TESTE(){
    
    getcwd(CURRENT_DIR, 500);
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    current_day = tm.tm_mday; current_month = tm.tm_mon + 1; current_year = tm.tm_year + 1900;
    this->method_SPP = method_SPP;

    cout<< "[INFO] Graph type: " << rd->G_type << endl; 
    initModel(method_SPP);



}

TFP_SCP_SIMP::~TFP_SCP_SIMP(){
    env.end();
}


void TFP_SCP_SIMP::initModel(const char* method_SPP){

    try{

        model = IloModel(env);
        initVariables();        

        if(method_SPP == "DijkstraComp" || method_SPP == "DijkstraTwoLabels"){
            cout << "[INFO] Creating Weighted Graph Shortest Positive Path " << endl;
            cout << "[INFO] Method: "<< method_SPP << endl;
            cout << "[WARNING]: Signed Graph must be balanced " << endl; // todo: add function to check if the graph is balanced


            double cpu0, cpu1;
            cpu0 = get_wall_time(); 
            
            GRAPH.genereateGraph_weighted("DijkstraComp");
            
            cpu1 = get_wall_time();
            this->time_GraphSPP = cpu1 - cpu0;

            createModel(model,x,y);

        }else if(method_SPP == "Matching" || method_SPP == "MinMatching"){
            
            cout << "[INFO] Creating Weighted Graph Shortest Positive Path " << endl;
            cout << "[INFO] Method: "<< method_SPP << endl;
            cout << "[WARNING]: Signed Graph must be not directed " << endl; // todo: check if graph is not directed

            double cpu0, cpu1;
            cpu0 = get_wall_time(); 
            
            GRAPH.genereateGraph_weighted("MinMatching");
            
            cpu1 = get_wall_time();
            this->time_GraphSPP = cpu1 - cpu0;

            createModel(model,x,y);


        }else if(method_SPP == "SEC_MTZ" || method_SPP == "MTZ"){
            cout << "[INFO] Creating Weighted Graph Shortest Positive Path " << endl;
            cout << "[INFO] ILP Method: "<< method_SPP << endl;

            cout << "not working yet" << endl;
            
            // create_GraphSPP_MTZ(model, x, y, f, lambda,mi);
            
        }else if(method_SPP == "SEC_SIGN" || method_SPP == "SIGN"){
            cout << "[INFO] Creating Weighted Graph Shortest Positive Path " << endl;
            cout << "[INFO] ILP Method: "<< method_SPP << endl;

            cout << "not working yet" << endl;
            // create_GraphSPP_MTZ(model, x, y, f, lambda,mu);
        }
        else{
            cout << "[ERROR] Method for Shortest Positive Paths not defined" << endl;
        }

        cplex = IloCplex(model);
        // exportILP(cplex,method_SPP);

    } catch (IloException& e) {
        cerr << "ERROR: " << e.getMessage()  << endl;
        cout << "\nError ilocplex" << endl;
        return;
    }catch (int e) {
            cerr << endl << "\nException occurred = " << e << endl;
    }


}

void TFP_SCP_SIMP::initVariables(){

    // var x[u][j][s] : if worker u is in projecet j with skill s
    // x = BoolVar3Matrix(env,rd->num_vertices);     
    x = BoolVar3Matrix(env,rd->num_vertices);
    for (int u=0; u<rd->num_vertices; u++){
        x[u] = BoolVarMatrix(env, rd->num_teams);
        for (int j = 0; j < rd->num_teams; j++)
            x[u][j] = IloBoolVarArray(env, rd->num_skills);
    }

    // var y[u][v][j] : if worker u and v is in the same project j
    y = BoolVar3Matrix(env,rd->num_vertices);
    for (int u=0; u<rd->num_vertices; u++){
        y[u] = BoolVarMatrix(env, rd->num_vertices);
        for (int v = u+1; v < rd->num_vertices; v++) // u<v
            y[u][v] = IloBoolVarArray(env, rd->num_teams);
    }

}

void TFP_SCP_SIMP::createModel(IloModel model, BoolVar3Matrix x, BoolVar3Matrix y){
    
    // add var x[u][j][s] in model
    for(int j=0; j<rd->num_teams; j++) // for all project j 
        for(int u=0; u< rd->num_vertices; u++) // for all worker u
            for(int s=0; s<rd->num_skills; s++){ 
                if(rd->K[u][s] > 0 && rd->R[j][s]>0){ // for all skills: s(u,j) skills of u and project j need skill u
                    char name[30];
                    sprintf(name, "x(%d,%d,%d)", u+1, j+1,s+1); // name not set all var beacause rd->K[u][s] > 0 && rd->R[j][s]>0 in definition have more vars
                    x[u][j][s].setName(name);
                    model.add(x[u][j][s]);
                }
            }

    // add var y[u][v][j]
    for(int u=0; u<rd->num_vertices; u++) // for all u 
        for(int v = u+1; v<rd->num_vertices; v++) // for all v: u<v
            for(int j = 0; j<rd->num_teams; j++){ // for all project j
                char name[30];
                sprintf(name, "y(%d,%d,%d)", u+1, v+1,j+1);
                y[u][v][j].setName(name);
                model.add(y[u][v][j]);
            }

    cout << "aqui" << endl;
    //object function
    objFunction(model,y);
     cout << "aqui 1" << endl;
    //constraints
    constr_OneTeam(model, x); // max one team with one skill
     cout << "aqui 2" << endl;
    constr_MinSkill(model, x); // min skill s per team j
     cout << "aqui 3" << endl;
    constr_LinY(model,x,y); // linearization y with x
     cout << "aqui 4" << endl;
    constr_Incomp(model,y); // negative edge incompatibility
    cout << "aqui 5" << endl;
}

void TFP_SCP_SIMP::objFunction (IloModel model, BoolVar3Matrix y){
    IloEnv env = model.getEnv();

    IloExpr objExpr(env);

    for(int u=0; u<rd->num_vertices; u++)
        for(int v=u+1; v<rd->num_vertices; v++)
            for(int j = 0; j<rd->num_teams; j++){
                if(rd->G[u][v] >= 0){objExpr += GRAPH.Graph_SPP[u][v]*y[u][v][j];}  // (u,v) not in E- or (u,v) in E'
            }

    IloObjective obj = IloMinimize(env, objExpr);
    model.add(obj);
    objExpr.end();
}

void TFP_SCP_SIMP::constr_OneTeam(IloModel model, BoolVar3Matrix x){
    
    IloEnv env = model.getEnv();

    // each worker uses at most one skill 
    for (int u=0; u<rd->num_vertices; u++) {
        IloExpr expr(env);
        for (int j = 0; j <rd->num_teams; j++) {
            for(int s = 0; s<rd->num_skills; s++){
                if(rd->R[j][s]>0 && rd->K[u][s]>0) // team j need skill s and indidual u have skill s
                    expr += x[u][j][s];
            }
        }
        model.add(expr <= 1);   //var empty_sum to know if expr is empty or not, only add if not
        expr.end();
    }
}

void TFP_SCP_SIMP::constr_MinSkill(IloModel model, BoolVar3Matrix x){
    IloEnv env = model.getEnv();

    // minimum number of individuals in project j with skill s
    for (int j=0; j <rd->num_teams; j++) {
        for (int s=0; s <rd->num_skills; s++) {
            IloExpr expr(env);
            if (rd->R[j][s] > 0) { //for all skill s in project j
                for (int u=0; u < rd->num_vertices; u++) {
                    if(rd->K[u][s] > 0) // if worker u have skill s
                        expr += x[u][j][s];
                }
                model.add(expr >= rd->R[j][s]);
                expr.end();
            }
        }
    }
}

void TFP_SCP_SIMP::constr_LinY(IloModel model, BoolVar3Matrix x, BoolVar3Matrix y){

    IloEnv env = model.getEnv();

    // set var y with x (linearization)
    for (int u=0; u<rd->num_vertices; u++)
        for (int v = u+1; v < rd->num_vertices; v++) // for all u,v: u<v
            // if (rd->G[u][v] >= 0  && GRAPH.Graph_SPP[u][v]>0){
                for (int j = 0; j <rd->num_teams; j++){
                    IloExpr exprU(env);
                    IloExpr exprV(env);
                    for (int s = 0; s < rd->num_skills; s++) {
                        if(rd->K[u][s] > 0 && rd->R[j][s] > 0) // individual u have skill s and team j need skill s
                            exprU += x[u][j][s];
                        if(rd->K[v][s] > 0 && rd->R[j][s] > 0)
                            exprV += x[v][j][s];
                    }
                    model.add(exprU + exprV - y[u][v][j] <= 1);
                    model.add(y[u][v][j]  <= exprU);
                    model.add(y[u][v][j] <= exprV);
                    exprU.end(); exprV.end();
                }
            // }
}


// can change to constranint with variables x
void TFP_SCP_SIMP::constr_Incomp(IloModel model, BoolVar3Matrix y){

    IloEnv env = model.getEnv();

    for(int u = 0; u<rd->num_vertices; u++)
        for(int v = u+1; v<rd->num_vertices; v++)
            if(rd->G[u][v] == -1 || GRAPH.Graph_SPP[u][v]==0){
                IloExpr expr(env);
                for(int j =0; j<rd->num_teams; j++)
                    expr += y[u][v][j];
                model.add(expr == 0);
                expr.end();
            }

}


void TFP_SCP_SIMP::printSolution(IloCplex& cplex,
                            BoolVar3Matrix x,
                            BoolVar3Matrix y){
    cout << "--------------------------------------------------------" << endl;

    cout << "Solution status = " << cplex.getStatus()   << endl;
    cout << "Solution value  = " << cplex.getObjValue() << endl;
    cout << "Valores das Variaveis " << endl;

    cout << "--------------------------------------------------------" << endl;
    cout << "--------------------------------------------------------" << endl;

    for(int j=0; j<rd->num_teams; j++)
        for(int u=0; u<rd->num_vertices; u++)
            for(int s=0; s<rd->num_skills; s++){
                if(rd->K[u][s] > 0 && rd->R[j][s]>0){
                    if(cplex.getValue(x[u][j][s]) > 0){
                        cout << "\t " << "x"<< "["<< u+1  << "," << j+1 << "," << s+1 << "]" << " -> " << " 1 \n";
                    }
                }
            }

    cout << "--------------------------------------------------------" << endl;

    for(int u=0; u<rd->num_vertices; u++)
        for(int v=u+1; v<rd->num_vertices; v++)
            for(int j=0; j<rd->num_teams; j++){
                if(cplex.getValue(y[u][v][j]) > 0){
                    cout << "\t " << "y"<< "["<< u+1  << "," << v+1 << "," << j+1 << "]" << " -> " << " 1 \n";
                }
            }

} 

void TFP_SCP_SIMP::saveSolution(IloCplex& cplex,
                    BoolVar3Matrix x,
                    BoolVar3Matrix y,
                    int class_type){

    char arq[1000];
    char arqv_instance[50];
    sprintf(arqv_instance, "%s_%d", instanceG,class_type);
    // sprintf(arq, "%s/results/%s.txt",CURRENT_DIR, arqv_instance);
    sprintf(arq, "%s/results/%d_Vertices_%d-%d-%d_TFP_SCP_SIMP_%c.csv",CURRENT_DIR, rd->num_vertices, current_year, current_month, current_day,method_SPP);

    FILE *file = fopen(arq, "w");
    if (file == NULL)
    {
        printf("Error opening file!\n");
        exit(1);
    }

    fprintf(file, "Solution value = %.1f \n", cplex.getObjValue());

    for(int j=0; j<rd->num_teams; j++)
        for(int u=0; u<rd->num_vertices; u++)
            for(int s=0; s<rd->num_skills; s++){
                if(rd->K[u][s] > 0 && rd->R[j][s]>0){
                    if(cplex.getValue(x[u][j][s]) > 0){
                        fprintf(file, "x[%d,%d,%d] = 1 \n", u+1, j+1, s+1);
                    }
                }
            }

    cout << "--------------------------------------------------------" << endl;

    for(int u=0; u<rd->num_vertices; u++)
        for(int v=u+1; v<rd->num_vertices; v++)
            for(int j=0; j<rd->num_teams; j++){
                if(cplex.getValue(y[u][v][j]) > 0){
                    fprintf(file, "y[%d,%d,%d] = 1 \n", u+1, v+1, j+1);
                }
            }

    fclose(file);                
}

// void TFP_SCP_SIMP::saveResults(IloCplex& cplex,
//                    double timeTFP, double time_WeightedGraph){
void TFP_SCP_SIMP::saveResults(double timeTotal){

    char arq[1000];
    // sprintf(arq, "%s/results/%d_Vertices_2022-06-27_cycle_mtz.ods",CURRENT_DIR, rd->num_vertices);
    sprintf(arq, "%s/results/result_%d_Vertices_%d-%d-%d_TFP_SCP_SIMP_%s.ods",CURRENT_DIR, rd->num_vertices, current_year, current_month, current_day,method_SPP);

    cout << arq << endl;

    ofstream outputTable;
    outputTable.open(arq,ios:: app);
    if(outputTable.is_open()){

        outputTable << rd->instanceG << ";"; // grafo instancia
        outputTable << rd->instanceKR << ";"; // KR instancia
        outputTable << rd->num_vertices << ";";   // numero de vertices
        outputTable << rd->num_skills << ";";   // qtd de hab
        outputTable << rd->num_teams << ";";   // qtd de proj
        outputTable << cplex.getStatus() << ";"; // Status cplex
        outputTable << cplex.getObjValue() << ";"; // valor fo
        outputTable << cplex.getNnodes() << ";"; // num nos
        outputTable << cplex.getMIPRelativeGap() <<";"; // gap
        outputTable << time_GraphSPP <<  ";"; // tempo execucao Grsph_SPP
        outputTable << timeTFP <<  ";"; // tempo execucao tfp (felipe)
        outputTable << cplex.getTime() <<  ";"; // tempo execucao tfp (cplex)
        outputTable << timeTotal <<  ";"; // tempo execucao tfp (cplex)
        outputTable << " \n ";


    }

    outputTable.close();




}


void TFP_SCP_SIMP::printInstance(){
    rd->show();
}


void TFP_SCP_SIMP::exportILP(IloCplex& cplex,const char* method_SPP){
    char ilpname[50];
    for(int i=0 ; i < 50 ; i++)
        ilpname[i] = 0;
    // string ilpname;
    strcat(ilpname, "TFP_SCP_simp-");
    strcat(ilpname, method_SPP);
    strcat(ilpname, ".lp");
    cout<< "[INFO]: Creating the the file lp: ";
    cout << ilpname << endl;
    cplex.exportModel(ilpname);
}

void TFP_SCP_SIMP::solveILP(){
    
    double cpu0, cpu1;
    cpu0 = get_wall_time(); 
    if (!cplex.solve()){
        env.error() << "Failed to optimize LP." << endl;
        throw(-1);
    }
    // else{
    //     printSolution(cplex,x,y);
    // }
    cpu1 = get_wall_time();
    this->timeTFP = cpu1 - cpu0; 
}

