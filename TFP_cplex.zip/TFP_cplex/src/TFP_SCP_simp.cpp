#include "TFP_SCP_simp.h"

TFP_SCP_SIMP::exportILP(Reader *r, const char* method_SPP): rd(r){

    getcwd(CURRENT_DIR, 500);
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    current_day = tm.tm_mday; current_month = tm.tm_mon + 1; current_year = tm.tm_year + 1900;
    this->method_SPP = method_SPP;

    cout<< "[INFO] Graph type: " << rd->G_type << endl; 
    initModel(method_SPP);



}

TFP_SCP_SIMP::~TFP_SCP_SIMP(){
    env.end();
}


void TFP_SCP_SIMP::initModel(const char* method_SPP){

    try{

        model = IloModel(env);
        initVariables();        

        if(method_SPP == "DijkstraComp" || method_SPP == "DijkstraTwoLabels"){
            cout << "[INFO] Creating Weighted Graph Shortest Positive Path " << endl;
            cout << "[INFO] Method: "<< method_SPP << endl;
            cout << "[WARNING]: Signed Graph must be balanced " << endl; // todo: add function to check if the graph is balanced

            createModel_MTZ(model, x, y, f, lambda,mi);
            Graph graph = Graph(rd.G, rd.num_vertices, rd.G_type);
            graph->genereateGraph_weighted("DijkstraComp");


        }else if(method_SPP == "Matching" || method_SPP == "MinMatching"){
            
            cout << "[INFO] Creating Weighted Graph Shortest Positive Path " << endl;
            cout << "[INFO] Method: "<< method_SPP << endl;
            cout << "[WARNING]: Signed Graph must be not directed " << endl; // todo: check if graph is not directed

            this.GRAPH = Graph(rd.G, rd.num_vertices, rd.G_type);
            GRAPH.genereateGraph_weighted("MinMatching");

            cout << " Graph Matrix Weighted SPP \n";
            for (int u = 0; u < rd.num_vertices; u++){
                for (int v = 0; v < rd.num_vertices; v++)
                cout <<  GRAPH.Graph_SPP[u][v] << " ";
                cout<< "\n";
            }



        }else if(method_SPP == "SEC_MTZ" || method_SPP == "MTZ"){
            cout << "[INFO] Creating Weighted Graph Shortest Positive Path " << endl;
            cout << "[INFO] ILP Method: "<< method_SPP << endl;

            cout << "not working yet" << endl;
            
            // create_GraphSPP_MTZ(model, x, y, f, lambda,mi);
            
        }else if(method_SPP == "SEC_SIGN" || method_SPP == "SIGN"){
            cout << "[INFO] Creating Weighted Graph Shortest Positive Path " << endl;
            cout << "[INFO] ILP Method: "<< method_SPP << endl;

            cout << "not working yet" << endl;
            // create_GraphSPP_MTZ(model, x, y, f, lambda,mu);
        }
        else{
            cout << "[INFO]: Method for Shortest Positive Paths not defined" << endl;
        }

        cplex = IloCplex(model);
        // exportILP(cplex,method_SPP);

    } catch (IloException& e) {
        cerr << "ERROR: " << e.getMessage()  << endl;
        cout << "\nError ilocplex" << endl;
        return;
    }catch (int e) {
            cerr << endl << "\nException occurred = " << e << endl;
    }


}

void TFP_SCP_SIMP::initVariables(){

    // var x[u][j][s] : if worker u is in projecet j with skill s
    // x = BoolVar3Matrix(env,rd->num_vertices);
    x = BoolVar3Matrix(env,rd->num_vertices);
    for (int u=0; u<rd->num_vertices; u++){
        x[u] = BoolVarMatrix(env, rd->num_teams);
        for (int j = 0; j < rd->num_teams; j++)
            x[u][j] = IloBoolVarArray(env, rd->num_skills);
    }

    // var y[u][v][j] : if worker u and v is in the same project j
    y = BoolVar3Matrix(env,rd->num_vertices);
    for (int u=0; u<rd->num_vertices; u++){
        y[u] = BoolVarMatrix(env, rd->num_vertices);
        for (int v = u+1; v < rd->num_vertices; v++) // u<v
            y[u][v] = IloBoolVarArray(env, rd->num_teams);
    }

}

void TFP_SCP_SIMP::createModel(IloModel model, BoolVar3Matrix x, BoolVar3Matrix y){
    
    // add var x[u][j][s] in model
    for(int j=0; j<rd->num_teams; j++) // for all project j 
        for(int u=0; u< rd->num_vertices; u++) // for all worker u
            for(int s=0; s<rd->num_skills; s++){ 
                if(rd->K[u][s] > 0 && rd->R[j][s]>0){ // for all skills: s(u,j) skills of u and project j need skill u
                    char name[30];
                    sprintf(name, "x(%d,%d,%d)", u+1, j+1,s+1); // name not set all var beacause rd->K[u][s] > 0 && rd->R[j][s]>0 in definition have more vars
                    x[u][j][s].setName(name);
                    model.add(x[u][j][s]);
                }
            }

    // add var y[u][v][j]
    for(int u=0; u<rd->num_vertices; u++) // for all u 
        for(int v = u+1; v<rd->num_vertices; v++) // for all v: u<v
            for(int j = 0; j<rd->num_teams; j++){ // for all project j
                char name[30];
                sprintf(name, "y(%d,%d,%d)", u+1, v+1,j+1);
                y[u][v][j].setName(name);
                model.add(y[u][v][j]);
            }

    //object function
    objFunction(model,y);
    //constraints
    constr_OneTeam(model, x); // max one team with one skill
    constr_MinSkill(model, x); // min skill s per team j
    constr_LinY(model,x,y); // linearization y with x
    constr_Incomp(model,y); // negative edge incompatibility

}

void TFP_SCP_SIMP::objFunction (IloModel model, BoolVar3Matrix y){
    IloEnv env = model.getEnv();

    IloExpr objExpr(env);
    for(int u=0; u<rd->num_vertices; u++)
        for(int v=u+1; v<rd->num_vertices; v++)
            for(int j = 0; j<rd->num_teams; j++){
                if(rd->G[u][v] >= 1){objExpr += y[u][v][j];}  // (u,v) in E+
            }

    IloObjective obj = IloMinimize(env, objExpr);
    model.add(obj);
    objExpr.end();
}